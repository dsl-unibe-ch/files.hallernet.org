<?xml version="1.0" ?>
<feed xmlns="http://www.w3.org/2005/Atom">
<title>Albrecht von Haller</title>
<link rel="alternate" type="text/html" href="www.albrecht-von-haller.ch" />
<link rel="self" type="application/atom+xml" href="http://www.albrecht-von-haller.ch/d/LightNEasy/atom.php" />
<id>tag:www.albrecht-von-haller.ch,2019-01-22:20190122</id>
<updated>2019-01-22T19:51:04+01:00</updated>
<entry>
	<title>News Title</title>
	<link rel="alternate" type="text/html" href="http://www.albrecht-von-haller.chnews.php?id=1" />
	<id>tag:www.albrecht-von-haller.ch,2011-05-01:20110501084617</id>
	<published>2019-01-22T19:51:04+01:00</published>
	<updated>2011-05-01T08:46:17+02:00</updated>
	<summary>This is some example news. Of course, you should edit/delete this news...</summary>
	<author>
		<name>Fernbap</name>
		<uri>http://www.albrecht-von-haller.ch</uri>
	</author>
	<category term="General" />
	<content type="html" xml:lang="en" xml:base="http://www.krakerjak.com/content/">
	<![CDATA[<p>This is some example news.</p> <p>Of course, you should edit/delete this news and enter your own.</p>]]>
	</content>
</entry>
</feed>