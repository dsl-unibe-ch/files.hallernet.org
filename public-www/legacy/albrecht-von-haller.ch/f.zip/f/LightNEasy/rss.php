<?xml version="1.0" ?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/RSS">
<channel>
<atom:link href="http://www.albrecht-von-haller.ch/f/LightNEasy/rss.php" rel="self" type="application/rss+xml" />
<title>Albrecht von Haller</title>
<description></description>
<link>http://www.albrecht-von-haller.ch/f/LightNEasy/rss.php</link>
<item>
<title>News Title</title>
<description>This is some example news. Of course, you should edit/delete this news and enter your own....
</description>
<link>http://www.albrecht-von-haller.ch/news.php?id=1</link>
<guid>http://www.albrecht-von-haller.ch/news.php?id=1</guid>
</item>
</channel>
</rss>
